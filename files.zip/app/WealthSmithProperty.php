<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WealthSmithProperty extends Model
{
    protected $table = 'properties';

    protected $guarded = [];
}
