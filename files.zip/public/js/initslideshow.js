//------------------------------init Superslides-----------------------
$('.transition-slider').superslides({
    animation: 'fade',
    play: 10000
});
$('#slides').superslides({
    animation: 'fade',
    play: 4000
});